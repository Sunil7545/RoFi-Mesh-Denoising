
import java.awt.Rectangle;

import jv.project.PjProject;

/**A mesh denoising algorithm in robust statistics and bilateral filtering framework.
 * This is the implementation of the following algorithm: 
 * Yadav, S. K., U. Reitebuch, and K. Polthier (2018). �Robust and High Fidelity Mesh Denoising�.
 *  In: IEEE Transaction on Vis. and Computer Graph.PP. 1�1.
 * @author		Sunil Kumar Yadav
 * @version		01.04.17, 1.00 created (SKY)
 * @version		18.06.18, 2.00 cleaning the code and proper documentation (SKY)
 */
public class PaRobustDenoising extends jv.project.PvApplet {
	
	private static final long serialVersionUID = 1L;

	/** Interface of applet to inform about author, version, and copyright */
	public String getAppletInfo() {
		return "Name: "		+ this.getClass().getName()+ "\r\n" +
		       "Author: "		+ "" + "\r\n" +
		       "Version: "	+ "" + "\r\n" +
				 "." + "\r\n";
	}
	/** Return a new allocated project instance. */
	public Rectangle getSizeOfFrame() {
		return new Rectangle(200, 5, 800, 700);
	}
	/** Return a new allocated project instance. */
	public PjProject getProject() {
		return new PjRobustDenoising();
	}
	
	public static void main(String args[]) {
		main(new PaRobustDenoising(), args);
	}
}