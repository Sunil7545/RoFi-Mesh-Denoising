
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import jv.geom.PgElementSet;
import jv.loader.PjImportModel;
import jv.number.PuDouble;
import jv.number.PuInteger;
import jv.object.PsConfig;
import jv.object.PsDebug;
import jv.project.PgGeometryIf;
import jv.project.PjProject;
import jv.project.PvGeometryIf;
import jv.project.PvViewerIf;
import jv.vecmath.PdVector;
import jv.vecmath.PiVector;

import jvx.geom.PgVertexStar;
import jvx.util.PuQueue;

/**A mesh denoising algorithm in robust statistics and bilateral filtering framework.
 * This is the implementation of the following algorithm: 
 * Yadav, S. K., U. Reitebuch, and K. Polthier (2018). �Robust and High Fidelity Mesh Denoising�.
 *  In: IEEE Transaction on Vis. and Computer Graph.PP. 1�1.
 * @author		Sunil Kumar Yadav
 * @version		01.04.17, 1.00 created (SKY)
 * @version		18.06.18, 2.00 cleaning the code and proper documentation (SKY)
 */
public class PjRobustDenoising extends PjProject implements ActionListener {

	private static final long serialVersionUID = 1L;

	/** Default noisy geometry model is displayed if no other geometry is loaded. */
	private		static String			m_defFileName = "fandisk_lowNoise.obj";

	/** Loaded geometry file including relative path. */
	protected	String					m_fileName;

	/** Project <code>PjImportModel</code> loads geometries from file. */
	protected   PjImportModel			m_import;

	/** input triangulated noisy mesh. */
	protected	PgElementSet			m_geom2;

	/** High fidelity mesh reconstruction factor. */
	protected	PuDouble				m_isoFactor;

	/** Shape of the Tukey's bi-weight kernel. */
	protected	PuDouble				m_normVar;

	/** Number of iterations for denoising the input model. */
	protected	PuInteger				m_noItera;

	/** Number of vertices in the input geometry. */
	protected 	int 							m_nov;

	/** Number of elements in the input geometry. */
	protected int 							m_noe;

	/** Number of edges in the input geometry. */
	protected int 							m_noedge;

	/** Initial vertex positions of edges in the input geometry. */
	protected PdVector	[]					m_vertices;

	/** To keep the original vertices intact. */
	protected PdVector	[]					m_origVertices;
	
	/** Indices of the vertex in each element of the input geometry. */
	protected PiVector	[]					m_elements;

	/** Element normals in the input geometry. */
	protected PdVector	[]					m_elemNormals;

	/** Neighbour elements of each elements in the input geometry. */
	protected PiVector	[]					m_elemNeigh;

	/** One connected element of each vertex. */
	protected PiVector						m_elemperVert;



	/**
	 * Constructor, without arguments to allow loading of project from menu.
	 */
	public PjRobustDenoising() {
		this(PsConfig.getCodeBase()+m_defFileName);
	}


	public PjRobustDenoising(String fileName) {
		super(fileName);
		if(fileName == null)
			fileName = "Unknown file name";
		m_fileName = fileName;
		m_import = new PjImportModel();
		m_import.setTypeOfInfoPanel(PjImportModel.SMALL_INFO_PANEL);
		m_import.setFileName(fileName);
		m_import.addActionListener(this);
		if(getClass()==PjRobustDenoising.class) {
			init();
		}
	}


	/**
	 * Do initialization of data structures; method is also used to reset instances.
	 */
	public void init() {
		super.init();

		m_isoFactor = new PuDouble("Iso Factor");
		m_isoFactor.addUpdateListener(this);
		m_isoFactor.setDefBounds(0, 10., 0.1, 0.1);
		m_isoFactor.setDefValue(0.2);
		m_isoFactor.init();

		m_noItera = new PuInteger("Number of Iteration");
		m_noItera.addUpdateListener(this);
		m_noItera.setDefBounds(0, 1000, 1, 5);
		m_noItera.setDefValue(100);
		m_noItera.init();

		m_normVar = new PuDouble("Range Variation");
		m_normVar.addUpdateListener(this);
		m_normVar.setDefBounds(0, 100, 0.1, 0.1);
		m_normVar.setDefValue(0.35);
		m_normVar.init();
	}


	/**
	 * Start project, e.g. start an animation. Method is called once when project is
	 * selected in PvViewer#selectProject(). Method is optional. For example, if an
	 * applet calls the start() method of PvViewer, then PvViewer tries to invoke
	 * the start() method of the currently selected project.
	 */
	public void start() {
		super.start();
		PvViewerIf viewer = getViewer();
		if (viewer != null) {
			String model = viewer.getParameter("model");
			if (model != null) {
				m_fileName = PsConfig.getCodeBase()+model;
			}
		}

		/** Load the default geometry with a local address of m_fileName. */
		m_import.load(m_fileName);			
		PgGeometryIf geom = m_import.getGeometry();
		setGeometry(geom);

		/** Add the geometry to the display panel and fit on the viewer's window. */
		addGeometry(geom);					
		fitDisplays();


		/** Compute the basic information regarding the geometry. */
		m_geom2 = (PgElementSet) geom;
		PgElementSet.triangulate(m_geom2);
		m_nov =  (m_geom2).getNumVertices();
		m_noe =  m_geom2.getNumElements();
		m_noedge = m_geom2.getNumEdges();
		m_vertices = m_geom2.getVertices();
		m_origVertices = PdVector.copyNew(m_vertices);
		m_elements = m_geom2.getElements();
		m_elemNeigh = m_geom2.getNeighbours();
		m_elemperVert = PgVertexStar.getElementPerVertex(m_geom2);
		m_geom2.makeElementNormals();
		m_elemNormals = m_geom2.getElementNormals();
		m_geom2.makeElementNormals();		
		System.out.println("Number of vertices in the geometry : " + m_nov);

	}

	/** Catch action events from the import loader when a new model was loaded. */
	public void actionPerformed(ActionEvent event){
		if (event.getSource() == m_import) {
			if (PsDebug.NOTIFY) PsDebug.notify("(m_import): called");
			if (m_import.getConfirm() == PjImportModel.CONFIRM_CLICKED) {
				if (m_import.getGeometry() instanceof PgElementSet) {	
					/** Add the geometry to the display panel and fit on the viewer's window. */
					addGeometry(m_import.getGeometry());					
					fitDisplays();
				}
			} else if (m_import.getConfirm() == PjImportModel.CONFIRM_CANCEL) {
				fitDisplays();
			} else if (m_import.getConfirm() == PjImportModel.CONFIRM_OK) {

				PgElementSet m_anElemSet = (PgElementSet)m_import.getGeometry();
				if(!addGeometry(m_anElemSet)) return;				
			}				
			fitDisplays();
		}

		/** Compute the basic information regarding the geometry. */
		m_geom2 = (PgElementSet) m_geom;
		PgElementSet.triangulate(m_geom2);
		m_nov =  (m_geom2).getNumVertices();
		m_noe =  m_geom2.getNumElements();
		m_noedge = m_geom2.getNumEdges();
		m_vertices = m_geom2.getVertices();
		m_origVertices = PdVector.copyNew(m_vertices);
		m_elements = m_geom2.getElements();
		m_elemNeigh = m_geom2.getNeighbours();
		m_elemperVert = PgVertexStar.getElementPerVertex(m_geom2);
		m_geom2.makeElementNormals();
		m_elemNormals = m_geom2.getElementNormals();
		m_geom2.makeElementNormals();		
		System.out.println("Number of vertices in the geometry : " + m_nov);
	}


	/** Return the valence of each vertex and average radius of the star*/

	/** to store the valence of each vertex*/
	PiVector [] m_valence;

	/** to store connected elements of each vertex*/
	PiVector [] m_elemValence;

	public void starValence(){
		/**to create a 1-ring vertex star*/
		PgVertexStar S = new PgVertexStar();

		/** to store the valence of each vertex*/
		m_valence = PiVector.realloc(null, m_nov, 3);

		/** to store connected elements of each vertex*/
		m_elemValence = PiVector.realloc(null, m_nov, 3);

		for(int k =0; k< m_nov; k++){

			/**Check for the boundary vertices*/
			if (m_geom2.getVertex(k).hasTag(PvGeometryIf.IS_BOUNDARY)) continue;

			/**Compute the vertex star of the corresponding vertex k. */
			S.makeVertexStar(m_geom2, k, m_elemperVert.m_data[k]);

			/** Vertices in the corresponding vertex star. */
			PiVector starVertInd = S.getLink();

			/**Elements in the corresponding vertex star. */
			PiVector starElemInd = S.getElement();

			/**Number of vertices in the corresponding vertex star.*/
			int val = starVertInd.getSize();

			/**Number of elements in the corresponding vertex star.*/
			int valElem = starElemInd.getSize();

			/**Store the indices of connected vertices.*/
			m_valence[k] = new PiVector(val);

			/**Store the indices of connected elements.*/
			m_elemValence[k] = starElemInd;
			//			m_vertStaravgDist[k] = new PdVector(val);
			for(int i = 0; i<val; i++ ){
				m_valence[k].m_data[i] = starVertInd.m_data[i];

			}

			for(int i = 0; i<valElem; i++ ){
				m_elemValence[k].m_data[i] = starElemInd.m_data[i];
				//				System.out.println("Connected elements : " + m_elemValence[k].m_data[i] + " at the vertex "+k);
			}


		}	
	}


	PdVector m_centroid;
	/** To calculate the triangle centroid, vertex indices are input */
	public void centroidElem(PiVector vertIndices){
		m_centroid = new PdVector(3);

		/**Size of the vertex*/
		int nov = vertIndices.getSize();
		for(int i =0; i<nov; i++){
			m_centroid.add(m_geom.getVertex(vertIndices.m_data[i]));
		}
		m_centroid.multScalar(1./nov);
	} 


	/** Computes the average distance between the elements of the input geometry */
	/** To store the average distance between the centroid of the elements*/
	PdVector m_avgDistFacet ;
	public void avgDistFace(){
		/**Create a vector*/
		m_avgDistFacet = new PdVector(m_noe);

		/**Neighbor elements*/
		PiVector elemNei;

		for (int i = 0; i < m_noe; i++) {

			/**compute the centroid of the corresponding element.*/
			centroidElem(m_elements[i]);
			PdVector centroid = m_centroid;    

			/** number of elements in neighborhood*/
			int non = m_elemNeigh[i].getSize();		

			/** avoid degenerate triangles*/
			if (non == 0) continue;

			/** To store distance between neighbour elements*/
			double elemDist = 0;
			for (int j = 0; j < non; j++) {

				/** To compute the distance between one neighbour element*/
				PdVector loc = new PdVector(3);
				PdVector locDiff = new PdVector(3);

				/** For boundary elements*/
				if(m_elemNeigh[i].m_data[j]<0) continue;

				/** neighbor element*/
				elemNei = m_elements[m_elemNeigh[i].m_data[j]];  
				centroidElem(elemNei);	
				loc = m_centroid;	

				/** distance between centroid of the concern element and neighbor element*/
				locDiff.sub(centroid, loc);					
				elemDist += locDiff.length();
			}
			m_avgDistFacet.m_data[i] = (elemDist/non);
		}

	}


	/** updated vertex positions*/
	PdVector [] m_vertUpdated;

	/** number of connected elements to each vertex*/
	PiVector m_vertFace;

	/** updated element normals*/
	PdVector [] m_elemNormUp;

	/** area of each elements*/
	PdVector m_elemArea;

	/** Sum of the area of the connected elements */
	PdVector m_vertArea;

	public void vertUpdatefromElem(){

		/**vertex star for neighborhood computation*/
		PgVertexStar S = new PgVertexStar();

		/** updated vertex positions*/
		m_vertUpdated = PdVector.realloc(null, m_nov, 3);

		/** number of connected elements to each vertex*/
		m_vertFace = new PiVector(m_nov);

		/** Sum of the area of the connected elements */
		m_vertArea = new PdVector(m_nov);
		m_vertArea.setConstant(0.);

		for(int i = 0; i<m_nov; i++){

			/** create the vertex star */
			S.makeVertexStar(m_geom2, i, m_elemperVert.m_data[i]);

			/** Get the local indices of the connected vertices */
			PiVector locInd = S.getVertexLocInd();    

			/** Get the local indices of the connected elements */
			PiVector neighEle = S.getElement();
			int numElem = neighEle.getSize();

			/** Store the number of connected elements */
			m_vertFace.m_data[i] = numElem;
			double locArea =0. ;
			for(int j = 0; j<numElem; j++){

				/** Sum of all the connected elements */
				locArea += m_elemArea.m_data[neighEle.m_data[j]];
				double loc = 0;

				/** Get the local indices of the vertices of the corresponding element */
				PiVector elemInd = m_elements[neighEle.m_data[j]];

				/** Get the central vertex of the vertex star */
				PdVector vert0 = m_vertices[elemInd.m_data[locInd.m_data[j]]];

				/** Get the other two vertices of the triangle */
				PdVector vert1 = m_vertices[elemInd.m_data[(locInd.m_data[j]+1)%3]];
				PdVector vert2 = m_vertices[elemInd.m_data[(locInd.m_data[j]+2)%3]];

				/** Compute the edge vectors */
				PdVector diff10 = new PdVector(3);
				PdVector diff21 = new PdVector(3);
				diff10.sub(vert1, vert0);
				diff21.sub(vert2, vert0);

				/** Orthogonality between edge vectors and updated face normal */
				loc = diff10.dot(m_elemNormUp[neighEle.m_data[j]])
						+diff21.dot(m_elemNormUp[neighEle.m_data[j]]);

				/** update the central vertex using gradient descent method  */
				m_vertUpdated[i].blendBase(m_vertUpdated[i], loc, m_elemNormUp[neighEle.m_data[j]]);
			}
			m_vertArea.m_data[i] = locArea;
		}

		/** update the basic geometry informations */
		m_geom2.makeElementNormals();
		m_geom2.makeVertexNormals();		
		m_geom2.update(m_geom2);

	}


	/**To track the status of the elements within growing disk */
	int[] m_elemStatus;

	/**A queue for the growing disk computation */
	PuQueue m_queue;

	/** Select elements within the given radius from a given central
	 *  elements and updated face normal in robust statistics framework*/
	public void tukeyGneighElem(PgElementSet geom, int startElem, double radius){

		/** To check the status of enqueued elements*/
		if (m_elemStatus == null || m_elemStatus.length != m_noe) {
			m_elemStatus = new int[m_noe];
			for (int i=0; i<m_noe; i++)
				m_elemStatus[i] = -1;
		}

		/** Declare the queue for starting and connected elements*/
		m_queue = new PuQueue(100);

		/** Start with given elements*/
		m_queue.enqueue(startElem);

		/**Provide a unique status that it is processed*/
		m_elemStatus[startElem] = startElem;

		/** To set the status of neighbor elements*/
		boolean [] elemInBall = new boolean[3];

		/**Centroid of the element*/
		centroidElem(m_elements[startElem]);	

		/**area of central element*/
		m_elemArea.m_data[startElem] = geom.getAreaOfElement(startElem);

		/**Kernel width of the closeness function*/
		double distVar = m_avgDistFacet.m_data[startElem];

		/**To locally store the updated normal*/
		PdVector updateNorm = new PdVector(3);

		/**Centroid of the central element*/
		PdVector centroid =PdVector.copyNew(m_centroid);  
		PdVector centNormal = m_elemNormals[startElem];

		/** Continue till the queue is not empty*/
		while (!m_queue.isEmpty()) {

			/**Extract the element from the queue*/
			int elemInd = m_queue.extractFirst();

			/**Get the neighbor elements corresponding to the extracted element*/
			PiVector neighElem = geom.getNeighbour(elemInd);

			/**Grow using the neighbour informations*/
			int nSize = neighElem.getSize();
			for (int i = 0; i < nSize; i++) {

				/**Check those elements are within the radius then set the status true otherwise false.*/
				int nInd = neighElem.m_data[i];

				/**Avoid boundary elements*/
				if(nInd<0) continue;

				/**Centroid of the neighbour elements*/
				centroidElem(m_elements[nInd]);

				/**Distance between the centroids of the neighbour element and central element*/
				double sqrDistCentroid = centroid.sqrDist(m_centroid);

				/**Check if it is within the user defined radius*/
				elemInBall[i] = (sqrDistCentroid< radius * radius) ;
				if (elemInBall[i] && (m_elemStatus[nInd]!=startElem)) {

					/**get the normal of the element if within radius and its difference from the central*/
					PdVector neighNormal = m_elemNormals[nInd];
					PdVector normDiff= PdVector.subNew(centNormal, neighNormal);

					/**Compute the closeness weighting factor*/
					double distWeight = Math.exp(-(sqrDistCentroid)/(2.*distVar*distVar));

					/**Compute the similarity weighting factor*/
					double normWeight = 0.0;
					if(normDiff.sqrLength() <= m_normalVar*m_normalVar){
						normWeight = 1*(1-(normDiff.sqrLength()/m_normalVar*m_normalVar))*(1-(normDiff.sqrLength()/m_normalVar*m_normalVar));
					}

					/**Compute the area weighting factor*/
					double area = geom.getAreaOfElement(nInd);
					m_elemArea.m_data[nInd]=area;

					/**Compute the total weighting factor*/
					double totalweight = distWeight*normWeight*area;

					/**Compute the weighting normal*/
					PdVector scaleNormal = new PdVector(3);
					scaleNormal.multScalar(m_elemNormals[nInd], totalweight);
					updateNorm.add(scaleNormal);
					m_queue.enqueue(nInd);
					m_elemStatus[nInd] = startElem;
				}
			}
		}

		/**Normalized the sum of all elements normal within the radius */
		updateNorm.normalize();
		m_elemNormUp[startElem] = updateNorm;
	}


	public void tukeybilateralNormalGneigh(){

		/**Input triangulated geometry*/

		PgElementSet geom = (PgElementSet)m_geom;

		/**To store the updated face normal*/
		m_elemNormUp = PdVector.realloc(null, m_noe, 3);

		/**To store the element areas*/
		m_elemArea = new PdVector(m_noe);

		/**Compute the updated normals in robust statistics framework*/
		double radius = m_avgDistFacet.average();
		for (int i = 0; i < m_noe; i++) {
			tukeyGneighElem(geom, i, 2.0*radius);		
		}
	}

	/**To store the differential coordinate*/
	protected	PdVector [] 	m_diffCoord;

	/**To store the barycenter of the one ring vertex*/
	protected 	PdVector []		m_weigtedCenroid;

	/**To store the tangent component of differential coordinates*/
	protected	PdVector [] 	m_diffCoordTan;	
	/**An isotropic method of regularize the mesh*/
	public void smoothCentroidOnUpdatedNormals() {

		/**Initialize the variables */
		m_weigtedCenroid = PdVector.realloc(null, m_nov, 3);
		m_diffCoord = PdVector.realloc(null, m_nov, 3);
		m_diffCoordTan = PdVector.realloc(null, m_nov, 3);

		/**Computes weighting factor for differential coordinate*/
		for (int i = 0; i < m_nov; i++) {

			/**To store the center of one ring*/
			PdVector center = new PdVector(3);

			/**weight to compute the equal distance from each vertex of the ring*/
			double weight = 0;

			/**Number vertex in the ring*/
			int linkSize = m_valence[i].getSize();

			for (int j = 0; j < linkSize; j++) {

				/**Indices of the vertices in the ring*/
				int w = m_valence[i].getEntry(j);

				/**Compute edge length from central vertex to the ring vertices*/
				double locDist = m_geom2.getVertex(w).dist(m_geom2.getVertex(i));

				/**Sum of the edge lengths as weighting factor*/
				weight += locDist;
				center.add(locDist, m_geom2.getVertex(w));
			}

			/**Compute the barycenter of the one ring vertex*/
			center.multScalar(1./weight);
			m_weigtedCenroid[i] = center;

			/**Differential coordinate*/
			m_diffCoord[i] = PdVector.subNew(center, m_vertices[i]);

			/**Now compute the corresponding updated vertex normal*/
			PdVector vertNormal = new PdVector(3);

			/**connected elements*/
			int elemSize = m_elemValence[i].getSize();

			/**Area weight*/
			double sumWeight = 0;

			for (int j = 0; j < elemSize; j++) {

				/**Indices of the elements in the ring*/
				int indexElem = m_elemValence[i].m_data[j];

				/**weighted sum of the element normals*/
				vertNormal.add(m_elemArea.m_data[indexElem], m_elemNormUp[indexElem]);
				sumWeight += m_elemArea.m_data[indexElem];
			}

			/**updated vertex normal*/
			vertNormal.multScalar(1./sumWeight);

			/**computes the tangential direction*/
			m_diffCoordTan[i] = PdVector.copyNew(m_diffCoord[i]);
			m_diffCoordTan[i].orthogonalPart(m_diffCoord[i], vertNormal);

		}
	}

	/**User input to add the amount isotropic smoothing which will lead to the high fidelity mesh 
	 * but at the same time it can destroy some features also so higher value is not recommended.
	 *  Mostly between 0.05-0.2 */
	double m_sw;

	/** Another User input to control the kernel width of the similarity function. Mostly between 0.2-0.5 */
	double m_normalVar;

	/**This is the main function regarding the robust and high fidelity mesh denoising*/
	public void regBilNormal(){

		/**To compute the running time*/
		long stTime = new java.util.Date().getTime();

		/**compute the valence of each vertex*/
		starValence();

		/**isotropic factor*/
		m_sw = m_isoFactor.getValue();

		/**average distance between the faces within 1-ring neighbour*/
		avgDistFace();	
		System.out.println(" Average dist Faces " +m_avgDistFacet.average());

		/**number of iterations and width of similarity function is given by user*/
		int numIt = m_noItera.getValue();
		m_normalVar = m_normVar.getValue();

		for(int n =0; n<numIt; n++){
			//			PdVector [] origVert = PdVector.copyNew(m_vertices);

			/**average distance between the faces within 1-ring neighbour*/
			avgDistFace();	

			/**Compute the updated elements normals*/
			tukeybilateralNormalGneigh();

			/**Compute the vertex position according to orthogonality between edge and element normals*/
			vertUpdatefromElem();

			/**Compute the high fidelity mesh reconstruction factor*/
			smoothCentroidOnUpdatedNormals();

			/**Update the vertex positions using the orthogonality between edge and element normals 
			 * and the high fidelity mesh reconstruction factor*/
			for(int i = 0; i<m_nov; i++ ){
				m_vertices[i].blendBase(m_vertices[i], 1./(3.*m_vertFace.m_data[i]), m_vertUpdated[i]);
				m_vertices[i].blendBase(m_vertices[i], m_sw, m_diffCoord[i]);
				m_vertices[i].blendBase(m_vertices[i], m_sw, m_diffCoordTan[i]);				
			}
			m_sw=m_sw*0.7;		
			PsDebug.showStatus(" Mesh Denoising "+((n+1.0)/numIt)*100.0 +"% ...");
		}

		/**Update corresponding geometry*/
		m_geom2.makeElementNormals();
		m_geom2.makeVertexNormals();
		m_geom2.update(m_geom2);
		long enTime = new java.util.Date().getTime();
		System.out.println(" Time taken during smoothing in seconds: " +(enTime-stTime)/1000.0);
	}


	/**This method computes mesh quality of the geometry using circumradius 
	 * and minimum edge length of the each triangle */
	public void circumCentre(){

		/**To store the circumcenter of each triangle*/
		PdVector [] circumCentre = PdVector.realloc(null, m_noe, 3);

		/**Mesh quality factor for each triangle*/
		PdVector qualityFactor = new PdVector(m_noe);

		for(int i = 0; i<m_noe; i++){

			/**get the indices of the vertices of the corresponding triangles */
			int a = m_elements[i].m_data[0];
			int b = m_elements[i].m_data[1];
			int c = m_elements[i].m_data[2];

			/**Edge vectors */
			PdVector ab = PdVector.subNew(m_vertices[b], m_vertices[a]);
			PdVector ac = PdVector.subNew(m_vertices[c], m_vertices[a]);

			/**Cross products */
			PdVector abXac = PdVector.crossNew(ab, ac);
			PdVector abXacXab =  PdVector.crossNew(abXac, ab);
			PdVector acXabXac =  PdVector.crossNew(ac, abXac);
			abXacXab.multScalar(ac.sqrLength());
			acXabXac.multScalar(ab.sqrLength());

			/**Circumcenter computation */
			PdVector loc = PdVector.addNew(abXacXab, acXabXac);
			if(abXac.sqrLength()<1e-16) continue;
			loc.multScalar(1./(2*abXac.sqrLength()));
			circumCentre[i]=loc;

			/**minimum edge length */
			PdVector bc =  PdVector.subNew(m_vertices[c], m_vertices[b]);
			PdVector length = new PdVector(3);
			length.m_data[0]=ab.length();
			length.m_data[1]=ac.length();
			length.m_data[2]=bc.length();
			length.sort();

			/**Quality factor*/
			if(length.m_data[0]<1e-16) continue;
			qualityFactor.m_data[i]=circumCentre[i].length()/length.m_data[0];
		}
//		int a = qualityFactor.indexOfAbsMax();
//		System.out.println(" Average and max Quality index for geometry" +a);
		//		PgElementSet geom = (PgElementSet) m_geom;
		//		geom.setTagElement(a, PsObject.IS_SELECTED);
		System.out.println(" Mesh Quality Factor Q: "+qualityFactor.average());
	}

	/**This method resets to the original input geometry */
	public void resetOrigGeom(){
		m_geom2.setVertices(m_origVertices);
		/**Update corresponding geometry*/
		m_geom2.makeElementNormals();
		m_geom2.makeVertexNormals();
		m_geom2.update(m_geom2);
	}
	
	
	

	/**
	 * Update method of project to react on changes in its panel or of its children.
	 * This method is optional, but required if project is parent of a child.
	 * Project becomes parent if child calls <code>child.setParent(this)</code> with
	 * this project as argument. For example, see the constructor of MyProject.
	 * Project must react on child events, or forward them to its superclass.
	 * <p>
	 * Catch events of integer children and recompute surface.
	 */
	public boolean update(Object event) {
		if(event == m_isoFactor){
			System.out.println("Isotropic Factor: "+m_isoFactor.getValue());
			return true;
		}else if(event == m_noItera){
			System.out.println("Number of Iteration: "+m_noItera.getValue());
			return true;
		}else if(event == m_normVar){
			System.out.println("Normal variation: "+ m_normVar.getValue());
			return true;
		}
		return super.update(event);
	}

}

