

import java.awt.Button;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import jv.object.PsDebug;
import jv.object.PsPanel;
import jv.object.PsUpdateIf;
import jv.project.PjProject_IP;
import jvx.project.PjWorkshop_IP;
/**A mesh denoising algorithm in robust statistics and bilateral filtering framework.
 * This is the implementation of the following algorithm: 
 * Yadav, S. K., U. Reitebuch, and K. Polthier (2018). �Robust and High Fidelity Mesh Denoising�.
 *  In: IEEE Transaction on Vis. and Computer Graph.PP. 1�1.
 * @author		Sunil Kumar Yadav
 * @version		01.04.17, 1.00 created (SKY)
 * @version		18.06.18, 2.00 cleaning the code and proper documentation (SKY)
 */
public class PjRobustDenoising_IP extends PjProject_IP implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected	PjRobustDenoising			m_pjtest;	
	protected   PjWorkshop_IP	m_infoPanel;
	protected	Button	m_regBilNorm;
	protected	Button	m_meshQuality;
	protected	Button	m_resetGeom;
	private		PsPanel m_BilNormPanel;

	public PjRobustDenoising_IP() {
		super();
		addTitle("RoFi Denoising");

		m_regBilNorm = new Button("RoFi Denoising");
		m_regBilNorm.addActionListener(this);

		m_meshQuality= new Button(" Mesh Quality");
		m_meshQuality.addActionListener(this);
		
		m_resetGeom= new Button("Reset");
		m_resetGeom.addActionListener(this);

		if (getClass() == PjRobustDenoising_IP.class) {
			init();
		}
	}
	
	
	public void init() {
		super.init();

		add(m_regBilNorm);
		m_BilNormPanel = new PsPanel(new GridLayout(3, 1));
		add(m_BilNormPanel);
		add(m_meshQuality);
		add(m_resetGeom);
	}
	
	
	public void setParent(PsUpdateIf parent) {
		super.setParent(parent);
		m_pjtest = (PjRobustDenoising)m_project;
		setTitle("RoFi Mesh Denoising");
		PsPanel pLoad = m_pjtest.m_import.getInfoPanel();
		add(pLoad);
		m_BilNormPanel.add(m_pjtest.m_normVar.newInspector(PsPanel.INFO_EXT));
		m_BilNormPanel.add(m_pjtest.m_isoFactor.newInspector(PsPanel.INFO_EXT));
		add(m_pjtest.m_noItera.newInspector(PsPanel.INFO_EXT));
	}
	
	/**
	 * Here we arrive from outside world of this panel, e.g. if
	 * project has changed somewhere else and must update its panel. Such an update
	 * is automatically by superclasses of PjProject.
	 */
	public boolean update(Object event) {
		if (m_pjtest==null) {
			if (PsDebug.WARNING) PsDebug.warning("missing parent, setParent not called");
			return false;
		}
		return super.update(event);
	}

	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();

		if(source == m_regBilNorm){
			m_regBilNorm.setBackground(new Color(200,0,0));
			((PjRobustDenoising)m_parent).regBilNormal();
			m_regBilNorm.setBackground(new Color(225,225,225));
		}
		else if(source == m_meshQuality){
			m_meshQuality.setBackground(new Color(200,0,0));
			((PjRobustDenoising)m_parent).circumCentre();
			m_meshQuality.setBackground(new Color(225,225,225));
		
	}else if(source == m_resetGeom){
		m_resetGeom.setBackground(new Color(200,0,0));
		((PjRobustDenoising)m_parent).resetOrigGeom();
		m_resetGeom.setBackground(new Color(225,225,225));
	}
}
}