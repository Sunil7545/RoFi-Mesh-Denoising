package vgp.tutor.avlTree;

import jv.geom.PgPolygonSet;
import jv.project.PjProject;
import jv.project.PvDisplayIf;
import jv.vecmath.PdVector;

import jvx.util.PuAVLTree;
import jvx.util.PuBinaryTreeNode;
import jvx.util.PuCompareStringsLexi;

/**
 * Tutorial project for testing AVL Tree.
 *
 * @author		Ulrich Reitebuch
 * @version 	26.04.2013, 1.00 created (ur)
 */
public class PjAvlTree extends PjProject {
	/** Geometry to work on. */
	protected PgPolygonSet	m_geom;
	/** AVL Tree */
	protected PuAVLTree		m_tree;
	
	/**
	 * Construct a new Aperiodic Tiling project.
	 */
	public PjAvlTree() {
		super("AVL Tree");

		m_geom = new PgPolygonSet(2);
		m_geom.setName("Tree");
		m_geom.showVertexLabels(true);
		m_geom.showVertexOutline(false);
		m_geom.setGlobalPolygonColor(new java.awt.Color(191, 191, 191));
		m_geom.setGlobalVertexSize(0.);
		m_geom.setLabelAttribute(jv.project.PvGeometryIf.GEOM_ITEM_POINT, 0, 0, jv.project.PgGeometryIf.LABEL_CENTER , jv.project.PgGeometryIf.LABEL_MIDDLE, 0);

		setGeometry(m_geom);
		// Create tree!		
		m_tree = new PuAVLTree(new PuCompareStringsLexi());
		computeGeom();
		
		if (getClass() == PjAvlTree.class)
			init();
	}

	/**
	 * Initializes the project.
	 */
	public void init() {
		super.init();

	}

	/**
	 * Register display in this project, add all geometries of project to the display,
	 * and register this project as pick listener in the display. The selected geometry
	 * of project will become the selected geometry in the display.
	 *
	 * @param         disp  Display.
	 */
	public void setDisplay(PvDisplayIf disp) {
		super.setDisplay(disp);
	}
	
	/**
	 * Set a geometry.
	 *
	 * @param		geom		Geometry to set. Must be an instance of PgPolygonSet.
	 */
	public boolean setGeometry(PgPolygonSet geom) {
		// Add geometry to display.
		if (m_geom != null)
			removeGeometry(m_geom);
		m_geom = geom;
		addGeometry(m_geom);
		selectGeometry(m_geom);

		return true;
	}
	
	/** Insert a new node into the tree. */
	public void insert(String name) {
		m_tree.insert(name);
		computeGeom();
		m_geom.update(m_geom);
	}
	/** Remove a node from the tree. */
	public void remove(String name) {
		m_tree.remove(name);
		computeGeom();		
		m_geom.update(m_geom);
	}
	
	/** Compute tree geometry. **/
	public void computeGeom() {
		int nov = m_tree.getSize();
		if (nov == 0)
			return;
		m_geom.setNumVertices(nov);
		m_geom.setDimOfPolygons(2);
		m_geom.setNumPolygons(nov-1);
		// Traverse tree.
		double scaleX = 1.;
		double scaleY = 1.;
		PuBinaryTreeNode[] n = new PuBinaryTreeNode[nov];
		int height = m_tree.getHeight();
		if (height < 1)
			height = 1;
		n[0] = m_tree.getRoot();
		m_geom.getVertex(0).setName((String)(n[0].getValue()));
		m_geom.getVertex(0).set(0.0, 0.0);
		int nextFreeIndex = 1;
		for (int i=0; i<nov; i++) {
			// Add Children
			PdVector v = m_geom.getVertex(i);
			PuBinaryTreeNode right = n[i].getRight();
			if (right != null) {
				n[nextFreeIndex] = right;
				m_geom.getVertex(nextFreeIndex).set(v.m_data[0]+1, v.m_data[1]-Math.pow(0.5, v.m_data[0]+1));
				m_geom.getPolygon(nextFreeIndex-1).set(i, nextFreeIndex);
				m_geom.getVertex(nextFreeIndex).setName((String)(right.getValue()));
				nextFreeIndex++;
			}
			PuBinaryTreeNode left = n[i].getLeft();
			if (left != null) {
				n[nextFreeIndex] = left;
				m_geom.getVertex(nextFreeIndex).set(v.m_data[0]+1, v.m_data[1]+Math.pow(0.5, v.m_data[0]+1));
				m_geom.getPolygon(nextFreeIndex-1).set(i, nextFreeIndex);
				m_geom.getVertex(nextFreeIndex).setName((String)(left.getValue()));
				nextFreeIndex++;
			}
			// Scale vertex i
			v.m_data[0] *= scaleX/(1.*height);
			v.m_data[1] *= scaleY;
		}
		
	}
	
	
}

