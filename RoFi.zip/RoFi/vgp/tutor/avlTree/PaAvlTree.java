package vgp.tutor.avlTree;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Frame;

import jv.object.PsViewerIf;
import jv.project.PvCameraIf;
import jv.viewer.PvViewer;

/**
 * Tutorial applet showing an AVL Tree. 
 *
 * @author		Ulrich Reitebuch
 * @version		26.04.2013, 1.00 created (ur)
 */
public class PaAvlTree extends Applet {
	/** Frame of the application. */
	public Frame		frame;
	/** Viewer. */
	public PvViewer	viewer;

	/**
	 * Initialize the project.
	 */
	public void init() {
		// viewer
		viewer = new PvViewer(this, frame);

		// project
		PjAvlTree project = new PjAvlTree();
		viewer.addProject(project);
		viewer.selectProject(project);
		viewer.getDisplay().selectCamera(PvCameraIf.CAMERA_ORTHO_XY);
		viewer.getDisplay().setBackgroundColor(Color.white);
		
		// display
		setLayout(new BorderLayout());
		add("Center", (Component) (viewer.getDisplay()));
		add("West", viewer.getPanel(PsViewerIf.PROJECT));
	}

	/**
	 * Starts the project.
	 */
	public void start() {
		viewer.start();
	}

	/**
	 * Called if run as application.
	 * Opens Applet in a new frame.
	 */
	public static void main(String args[]) {
		PaAvlTree app = new PaAvlTree();
		Frame frame = new jv.object.PsMainFrame(app, args);
		frame.setTitle("AvlTree");
		frame.pack();
		app.frame = frame;
		app.init();
		app.start();
		frame.setSize(1000, 640);
		frame.setLocation(400, 0);
		frame.setVisible(true);
	}
}