package vgp.tutor.jvfModel;


import java.applet.Applet;
import java.awt.*;

import jv.project.PvDisplayIf;
import jv.viewer.PvViewer;

import jvx.primitive.PgCircleF;
import jvx.primitive.PgCurveF;
import jvx.primitive.PgPlotF;
import jvx.primitive.PgPointF;
import jvx.primitive.PgSegmentF;

public class PaJvfPrimitive extends Applet {
	/**
	 * If variable m_frame!=null then this applet runs in an application,
	 * otherwise applet runs inside an Html page within a browser.
	 * Further, when running as application then this frame is the container
	 * of the applet.
	 */
	public		Frame				m_frame			= null;
	/**
	 * 3D-viewer window for graphics output, display is embedded into the applet.
	 * This instance variable allows JavaView to perform start, stop and destroy
	 * operations when the corresponding methods of this applet are called,
	 * for example, by a browser.
	 */
	protected	PvViewer			m_viewer;

	/**
	 * Configure and initialize the viewer, load system and user projects.
	 * One of the user projects must be selected here.
	 */
	public void init() {
		// Create viewer for viewing 3d geometries. References to the applet and frame
		// allow JavaView to decide whether program runs as applet or standalone application,
		// and, in the later case, it allows to use the frame as parent frame.
		m_viewer = new PvViewer(this, m_frame);
		PvDisplayIf disp		= m_viewer.getDisplay();
		disp.setEnabledZBuffer(true);
		disp.setMajorMode(PvDisplayIf.MODE_VERTICAL);

		/*
		// Create and show various functional geometry classes.
		PgSphere sphere		= new PgSphere();
		sphere.showElements(false);
		sphere.setRadius(1.5);
		sphere.setGlobalEdgeColor(Color.white);
		sphere.compute();
		disp.addGeometry(sphere);
		
		PgCircle circle		= new PgCircle();
		circle.setNumVertices(50);
		circle.setRadius(2.5);
		circle.compute();
		disp.addGeometry(circle);

		PgGraphF graphF		= new PgGraphF();
		graphF.computeSample();
		graphF.getFunction().setExpression("sin(u*v)-2.");
		graphF.compute();
		graphF.setEnabledSynchronization(true);
		graphF.makeElementColorsFromZHue();
		graphF.showElementColors(true);
		graphF.update(graphF);
		disp.addGeometry(graphF);
		*/

		PgCircleF circleF		= new PgCircleF();
		circleF.computeSample();
		disp.addGeometry(circleF);

		PgPointF pointF		= new PgPointF();
		pointF.computeSample();
		disp.addGeometry(pointF);

		PgSegmentF segmentF	= new PgSegmentF();
		segmentF.computeSample();
		disp.addGeometry(segmentF);

		PgCurveF curveF		= new PgCurveF();
		curveF.computeSample();
		disp.addGeometry(curveF);

		PgPlotF plotF		= new PgPlotF();
		plotF.computeSample();
		disp.addGeometry(plotF);

		
		disp.selectGeometry(plotF);

		setLayout(new BorderLayout());
		// Get 3d display from viewer and add it to applet
		add(disp.getCanvas(), BorderLayout.CENTER);
	}
	/**
	 * Standalone application support. The main() method acts as the applet's
	 * entry point when it is run as a standalone application. It is ignored
	 * if the applet is run from within an HTML page.
	 */
	public static void main(String args[]) {
		PaJvfPrimitive app	= new PaJvfPrimitive();
		// Create toplevel window of application containing the applet
		Frame frame	= new jv.object.PsMainFrame(app, args);
		frame.pack();
		// Store the variable frame inside the applet to indicate
		// that this applet runs as application.
		app.m_frame = frame;
		app.init();
		// In application mode, explicitly call the applet.start() method.
		app.start();
		// Set size of frame when running as application.
		frame.setSize(640, 550);
		frame.setVisible(true);
	}
	
	/**
	 * Does clean-up when applet is destroyed by the browser.
	 * Here we just close and dispose all our control windows.
	 */
	public void destroy()	{ m_viewer.destroy(); }

	/** Start viewer, e.g. start animation if requested */
	public void start()		{ m_viewer.start(); }

	/** Stop viewer, e.g. stop animation if requested */
	public void stop()		{ m_viewer.stop(); }
}

