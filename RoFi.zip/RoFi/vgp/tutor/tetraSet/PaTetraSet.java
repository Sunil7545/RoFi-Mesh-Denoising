package vgp.tutor.tetraSet;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Rectangle;

import jv.object.PsConfig;
import jv.project.PvDisplayIf;
import jv.viewer.PvViewer;

import jv.geom.PgTetraSet;


/**
 * Generate and display a sample cubical grid as PgTetraSet.
 * 
 * @author		Konrad Polthier
 * @version		08.03.10, 1.10 revised (ur) Functionality moved to PwTetraSet Workshop.<br>
 * 				23.06.07, 1.00 created (kp)
 */
public class PaTetraSet extends Applet {
	/** frame if run standalone, null if run as applet */
	public Frame				m_frame			= null;
	/** 3D-viewer window for graphics output and which is embedded into the applet. */
	protected PvViewer		m_viewer;
	/** Set of tetrahedra tesselating the space domain.*/
	private PgTetraSet		m_tetra;

	/**
	 * Message string drawn in applet while loading.
	 * Modify string with drawMessage().
	 */
	private String				m_drawString	= "Initializing ...";
	/**
	 * Interface of applet to inform about author, version, and copyright.
	 *
	 * @return		A <code>String</code> with the applet info.
	 */
	public String getAppletInfo() {
		return "Name: " + this.getClass().getName() + "\r\n" + "Author: " + PsConfig.getAuthors()
				+ "\r\n" + "Version: " + PsConfig.getVersion() + "\r\n"
				+ "Applet shows refinement of tetrahedral volumes" + "\r\n";
	}

	/**
	 * Configure and initialize the viewer, load system and user projects.
	 * One of the user projects must be selected here.
	 */
	public void init() {
		drawMessage("Loading viewer ...");
		m_viewer = new PvViewer(this, m_frame);

		drawMessage("Loading geometry ...");
		m_tetra = new PgTetraSet(3); // create a new geometry
		m_tetra.setName("Cubical Volume");
		m_tetra.computeBox(3, 3, 3, -1., -1., -1., 1., 1., 1.);

		// Get 3d display from viewer and add it to applet.
		setLayout(new BorderLayout());
		add(m_viewer.getDisplay().getCanvas(), BorderLayout.CENTER);

		PvDisplayIf disp = m_viewer.getDisplay();
		disp.setEnabledZBuffer(true);
		disp.addGeometry(m_tetra);
		
		validate();

	}

	/**
	 * Main method for Standalone application support.
	 *
	 * @param		args	A <code>String</code> array with the commandline arguments.
	 */
	public static void main(String args[]) {
		PaTetraSet va = new PaTetraSet();
		Frame frame = new jv.object.PsMainFrame(va, args);
		va.m_frame = frame;
		va.init();
		frame.setBounds(new Rectangle(420, 5, 640, 600));
		frame.setVisible(true);
	}

	/**
	 * Show info text during initialization.
	 *
	 * @param		g   A <code>Graphics</code> object.
	 */
	public void paint(Graphics g) {
		g.setColor(Color.blue);
		g.drawString(PsConfig.getProgramAndVersion(), 20, 40);
		g.drawString(m_drawString, 20, 60);
	}

	/**
	 * Print info while initializing applet and viewer.
	 *
	 * @param		message	A <code>String</code> with a message.
	 */
	private void drawMessage(String message) {
		m_drawString = message;
		repaint();
	}

	/**
	 * Does clean-up when applet is destroyed by the browser.
	 * Here we just close and dispose all our control windows.
	 */
	public void destroy() {
		if (m_viewer != null) m_viewer.destroy();
	}

	/** Stop viewer, that is stop animation if requested. */
	public void stop() {
		if (m_viewer != null) m_viewer.stop();
	}
}
