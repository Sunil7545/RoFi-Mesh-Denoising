package vgp.tutor.parmCurve;

import jv.object.PsConfig;
import jv.object.PsPanel;
import jv.object.PsUpdateIf;
import jv.project.PjProject_IP;

/**
 * Info panel for PjParmCurve with panels for parametrized curve.
 * 
 * @see			jvx.curve.PgParmCurve_CP
 * @author		Eike Preuss
 * @version		11.06.02, 1.00 created (ep)
 */
public class PjParmCurve_IP extends PjProject_IP {
	protected	PjParmCurve			m_pjParmCurve;

	public PjParmCurve_IP() {
		super();
		if (getClass() == PjParmCurve_IP.class) {
			init();
		}
	}
	public void init() {
		super.init();
		addTitle("");
	}
	public void setParent(PsUpdateIf parent) {
		super.setParent(parent);
		m_pjParmCurve = (PjParmCurve)parent;
		setTitle(PsConfig.getMessage(28003)+" "+m_pjParmCurve.getName());
		// Create an info panel of the workshop by ourself
		PsPanel cp = m_pjParmCurve.m_parmCurve.newInspector(PsPanel.CONFIG_EXT);
		cp.setBorderType(PsPanel.BORDER_NONE);
		add(cp);
		validate();
	}
}
