package vgp.tutor.slider;

import java.awt.*;
import java.applet.Applet;

import jv.object.PsConfig;

/**
 * Tutorial applet shows usage of double and integer sliders.
 * 
 * @version		04.02.07, 1.20 revised (kp) Missing initialization of PsConfig added.<br>
 * 				16.09.01, 1.10 revised (kp) Name changed from slider_Applet.java according to naming convention.<br>
 */
public class PaSlider extends Applet {
	/** frame if run standalone, null if run as applet */
	public		Frame				m_frame			= null;
	
	/** Interface of applet to inform about author, version, and copyright */
	public String getAppletInfo() {
		return "Name: "		+ this.getClass().getName()+ "\r\n" +
				 "Author: "		+ "Ulrich Reitebuch" + "\r\n" +
				 "Version: "	+ "1.20" + "\r\n" +
				 "Demo applet for usage of sliders for integers and doubles in JavaView" + "\r\n";
	}

	/**
	 * Initialize the panel.
	 * One of the user projects must be selected here.
	 */
	public void init () {
		// JavaView's configuration class needs to know if running as applet or application.
		PsConfig.init(this, m_frame);

		// Create project and add its inspector to applet.
		PjSlider project = new PjSlider();
		setLayout(new BorderLayout());
		add(project.getInfoPanel(), BorderLayout.CENTER);
		validate();
	}
	
	/**
	 * Standalone application support. The main() method acts as the applet's
	 * entry point when it is run as a standalone application. It is ignored
	 * if the applet is run from within an HTML page.
	 */
	public static void main(String args[]) {
		PaSlider app	= new PaSlider();
		// Create toplevel window of application containing the applet
		Frame frame	= new jv.object.PsMainFrame(app, args);
		frame.pack();
		app.m_frame = frame;
		app.init();
		// Position of left upper corner and size of frame when run as application.
		frame.setBounds(new Rectangle(420, 5, 350, 100));
		frame.setVisible(true);
	}
}
