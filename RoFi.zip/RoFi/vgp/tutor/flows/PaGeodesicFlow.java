package vgp.tutor.flows;
import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Rectangle;

import jv.geom.PgElementSet;
import jv.loader.PjImportModel;
import jv.object.PsConfig;
import jv.object.PsDebug;
import jv.object.PsDialog;
import jv.project.PvDisplayIf;
import jv.viewer.PvViewer;

import jvx.geom.PwGeodesicFlow;
import jvx.project.PjWorkshop_Dialog;

/**
 * Demo applet for the PwGeodesicFlow workshop.
 * @author		Andreas Haferburg
 * @see jv.viewer.PvViewer
 */
public class PaGeodesicFlow extends Applet implements Runnable {
	/** frame if run standalone, null if run as applet */
	public		Frame						m_frame;
	/** 3D-viewer window for graphics output and which is embedded into the applet */
	protected	PvViewer					m_viewer;
	/**
	 * Message string drawn in applet while loading. Modify string with drawMessage().
	 */
	private		String					m_drawString	= "Initializing ...";
	/** Test model with vector fields. */
	protected	static final String	m_modelName		= "models/vector/brezelVector.jvx";
	
	/** Interface of applet to inform about author, version, and copyright */
	public String getAppletInfo() {
		return "Name: "		+ this.getClass().getName()+ "\r\n" +
				 "Author: "		+ "Andreas Haferburg" + "\r\n" +
				 "Version: "	+ "1.00" + "\r\n" +
				 "Visualize Vectorfields on Triangulations using Seeds" + "\r\n";
	}
	
	/**
	 * Create thread that configures and initializes the viewer, loads system and user projects.
	 */
	public void init() {
		Thread thread = new Thread(this, "JavaView: inititialize applet");
		thread.setPriority(Thread.NORM_PRIORITY);
		thread.start();
	}
	/**
	 * Configure and initialize the viewer, load system and user projects.
	 * One of the user projects may be selected here.
	 */
	public void run() {
		drawMessage("Loading viewer ...");
		// Create viewer for viewing 3d geometries
		m_viewer = new PvViewer(this, m_frame);
		
		String fileName = PsConfig.getCodeBase()+m_modelName;
		PjImportModel model = new PjImportModel();
		PgElementSet geo = null;
		PvDisplayIf disp = m_viewer.getDisplay();
		if (!model.load(fileName)) {
			PsDebug.message("PjModel.start(): failed to load geometry from file "+fileName);
			return;
		}
		geo = (PgElementSet)model.getGeometry().clone();
		disp.addGeometry(geo);
		
		//Set visual properties of vector field
		//m_elementSet.showVectorArrows(true);
		geo.setGlobalVectorColor(Color.black);
		geo.setGlobalElementColor(Color.white);
		geo.showVectorFields(false);
		
		//Set visual properties of element set
		geo.showEdges(false);
		geo.showElementTexture( false );
		//geo.showElements(false);
		geo.setVisible(true);
		geo.update(null);
		
		PwGeodesicFlow workshop = new PwGeodesicFlow();
		workshop.setGeometry(geo);
		workshop.setDisplay(disp);
		
		disp.setBackgroundColor( Color.white );
		disp.setEnabledZBuffer( true );
		disp.setEnabledPainters( false );
		//disp.setEnabledRepaint( false );
		PsDialog dialog = new PjWorkshop_Dialog(false);
		dialog.setParent(workshop);
		dialog.update(workshop);
		dialog.setVisible(true);
		
		// Get 3d display from viewer and add it to applet
		setLayout(new BorderLayout());
		add(m_viewer.getDisplay().getCanvas(), BorderLayout.CENTER);
		validate();
		
		// Explicitly start the applet
		startFromThread();
	}
	/**
	 * Standalone application support. The main() method acts as the applet's
	 * entry point when it is run as a standalone application. It is ignored
	 * if the applet is run from within an HTML page.
	 */
	public static void main(String args[]) {
		PaGeodesicFlow va	= new PaGeodesicFlow();
		// Create toplevel window of application containing the applet
		Frame frame	= new jv.object.PsMainFrame(va, args);
		frame.pack();
		va.m_frame = frame;
		va.init();
		va.start();
		frame.setBounds(new Rectangle(420, 5, 640, 550));
		frame.setVisible(true);
	}
	
	/** Set message string to be drawn in applet while loading. */
	private void drawMessage(String message) {
		m_drawString = message;
		repaint();
	}
	/**
	 * Print info while initializing applet and viewer.
	 * @param g
	 */
	public void paint(Graphics g) {
		g.setColor(Color.blue);
		g.drawString(PsConfig.getProgramAndVersion(), 20, 40);
		g.drawString(m_drawString, 20, 60);
	}
	/**
	 * Does clean-up when applet is destroyed by the browser.
	 * Here we just close and dispose all our control windows.
	 */
	public void destroy()			{ if (m_viewer != null) m_viewer.destroy(); }
	
	/** Stop viewer, e.g. stop animation if requested */
	public void stop()				{ if (m_viewer != null) m_viewer.stop(); }
	/**
	 * Start viewer, e.g. start animation if requested.
	 * Necessary, if initialization is done in a separate thread. In this case the original
	 * applet.start() has no effect.
	 */
	public void startFromThread()	{ if (m_viewer!=null) m_viewer.start(); }
}
